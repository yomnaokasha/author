import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link, navigate } from "@reach/router";
const Edit = (props) => {
  const { id } = props;
  const [name, setName] = useState("");
  const [errors, setErrors] = useState([]);
  const [authorNotFound, setAuthorNotFound] = useState(false);
  useEffect(() => {
    axios
      .get("http://localhost:8002/api/authors/" + id)
      .then((res) => {
        setName(res.data.Author.name);
      })
      .catch((err) => {
        setAuthorNotFound(true);
        console.log(err);
      });
  }, []);
  const updatePerson = (e) => {
    e.preventDefault();
    axios
      .put("http://localhost:8002/api/authors/" + id, {
        name,
      })
      .then((res) => {
        console.log(res);
        navigate("/");
      })
      .catch((err) => {
        const errorResponse = err.response.data.error.errors;
        const errorArr = [];
        for (const key of Object.keys(errorResponse)) {
          // Loop through all errors and get the messages
          errorArr.push(errorResponse[key].message);
        }
        setErrors(errorArr);
      });
  };
  if (authorNotFound) {
    return (
      <div>
        <p>
          We're sorry, but we could not find the author you are looking for.
          Would you like to add an author to our database?
        </p>
        <Link to="/new">Add</Link>
      </div>
    );
  }
  return (
    <div>
      <h1>Favorite Author</h1>
      <Link to="/"> Home</Link>
      <form onSubmit={updatePerson}>
        <h2>Edit Author</h2>
        <p>
          <label> Name :</label>
          <br />
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
        </p>
        {errors.map((errorMessage, index) => (
          <p key={index} style={{ color: "red" }}>
            {errorMessage}
          </p>
        ))}
        <div>
          <button type="button" onClick={(e) => navigate("/")}>
            Cancel
          </button>
          <input type="submit" />
        </div>
      </form>
    </div>
  );
};
export default Edit;
