import React, { useState } from "react";
import axios from "axios";
import { Link, navigate } from "@reach/router";
const AuthorForm = () => {
  const [name, setName] = useState("");
  const [errors, setErrors] = useState([]);

  const onSubmitHandler = (e) => {
    e.preventDefault();
    axios
      .post("http://localhost:8002/api/authors", {
        name,
      })
      .then((res) => {
        console.log(res.data);
        navigate("/");
      })
      .catch((err) => {
        const errorResponse = err.response.data.error.errors;
        const errorArr = [];
        for (const key of Object.keys(errorResponse)) {
          // Loop through all errors and get the messages
          errorArr.push(errorResponse[key].message);
        }
        setErrors(errorArr);
      });
  };

  return (
    <form onSubmit={onSubmitHandler}>
      <h1> Favorite Author</h1>
      <Link to="/"> Home</Link>
      <h2>Add a New Author</h2>
      <p>
        <label> Name :</label>
        <br />
        <input type="text" onChange={(e) => setName(e.target.value)} />
      </p>
      {errors.map((errorMessage, index) => (
        <p key={index} style={{ color: "red" }}>
          {errorMessage}
        </p>
      ))}
      <div>
        <button type="button" onClick={() => navigate("/")}>
          Cancel
        </button>
        <input type="submit" />
      </div>
    </form>
  );
};
export default AuthorForm;
