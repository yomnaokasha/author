import React, { useState, useEffect } from "react";
import axios from "axios";
import { Link, navigate } from "@reach/router";
const AuthorList = (props) => {
  const [authors, setAuhtors] = useState([]);

  useEffect(() => {
    axios
      .get("http://localhost:8002/api/authors")
      .then((res) => {
        console.log(res.data);
        setAuhtors(
          res.data.Authors.sort((a, b) => {
            if (a.name < b.name) {
              return -1;
            } else if (a.name > b.name) {
              return 1;
            } else {
              return 0;
            }
          })
        );
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);
  const deleteAuthor = (authorId) => {
    axios
      .delete("http://localhost:8002/api/authors/" + authorId)
      .then((res) => {
        setAuhtors(authors.filter((author) => author._id != authorId));
      })
      .catch((err) => console.log(err));
  };

  return (
    <div>
      <h1>Favorite Authors</h1>
      <Link to="/new">Add a New Author</Link>
      <h2>We have Quoted by :</h2>
      <table>
        <thead>
          <tr>
            <th>Authors</th>
            <th>Action Avaliables</th>
          </tr>
        </thead>
        <tbody>
          {authors.map((author, index) => {
            return (
              <tr key={index}>
                <td>{author.name}</td>
                <td>
                  <button onClick={() => navigate("/edit/" + author._id)}>
                    Edit
                  </button>
                  <button
                    onClick={(e) => {
                      deleteAuthor(author._id);
                    }}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};
export default AuthorList;
