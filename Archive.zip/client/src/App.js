import "./App.css";
import { Router } from "@reach/router";
import AuthorForm from "./componant/form";
import Edit from "./componant/edit";
import AuthorList from "./componant/list";

function App() {
  return (
    <div className="App">
      <Router>
        <AuthorList path="/" />
        <AuthorForm path="/new" />
        <Edit path="/edit/:id" />
      </Router>
    </div>
  );
}

export default App;
